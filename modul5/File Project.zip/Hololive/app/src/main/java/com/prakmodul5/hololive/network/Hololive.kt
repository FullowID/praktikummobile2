package com.prakmodul5.hololive.network

data class Hololive(
    val channels: List<ChannelsItem>? = null,
)

data class ChannelsItem(
    val name: String? = null,
    val description: String? = null,
    val photo: String? = null,
    val id: Int? = null
)


package com.prakmodul5.hololive.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.prakmodul5.hololive.databinding.ItemRvBinding
import com.prakmodul5.hololive.network.ChannelsItem

class HoloListAdapter(private val clickListener: HololiveListener) :
    ListAdapter<ChannelsItem, HoloListAdapter.HoloViewHolder>(DiffCallback) {
    class HoloViewHolder(
        var binding: ItemRvBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(clickListener: HololiveListener, hololive: ChannelsItem) {
            binding.holoItem = hololive
            binding.clickListener = clickListener
            binding.executePendingBindings()
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<ChannelsItem>() {
        override fun areItemsTheSame(oldItem: ChannelsItem, newItem: ChannelsItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ChannelsItem, newItem: ChannelsItem): Boolean {
            return oldItem.name == newItem.name
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HoloViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return HoloViewHolder(
            ItemRvBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: HoloViewHolder, position: Int) {
        val holo = getItem(position)
        holder.bind(clickListener, holo)
    }

}

class HololiveListener(val clickListener: (holo: ChannelsItem) -> Unit) {
    fun onClick(holo: ChannelsItem) = clickListener(holo)
}
package com.prakmodul5.hololive.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.divider.MaterialDividerItemDecoration
import com.prakmodul5.hololive.R
import com.prakmodul5.hololive.databinding.FragmentHoloListBinding

class HoloListFragment : Fragment() {
    private val viewModel: HoloListViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentHoloListBinding.inflate(inflater)
        viewModel.getHololiveData()
        binding.lifecycleOwner = viewLifecycleOwner
        binding.viewModel = viewModel
        binding.rv.adapter = HoloListAdapter(HololiveListener { holo ->
            viewModel.onHololiveItemClicked(holo)
            findNavController()
                .navigate(R.id.action_holoListFragment_to_holoDetailFragment)
        })

        (activity as AppCompatActivity).supportActionBar?.title = "Data Vtuber Hololive"
        binding.rv.addItemDecoration(
            MaterialDividerItemDecoration(
                requireContext(),
                LinearLayoutManager.VERTICAL
            )
        )


        return binding.root
    }
}
package com.prakmodul5.hololive.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.prakmodul5.hololive.network.ChannelsItem
import com.prakmodul5.hololive.network.HoloApi
import kotlinx.coroutines.launch

enum class HololiveApiStatus { LOADING, ERROR, DONE }
class HoloListViewModel : ViewModel() {
    private val _status = MutableLiveData<HololiveApiStatus>()
    val status: LiveData<HololiveApiStatus> = _status

    private val _hololives = MutableLiveData<List<ChannelsItem>?>()
    val hololives: MutableLiveData<List<ChannelsItem>?> = _hololives

    private val _hololive = MutableLiveData<ChannelsItem>()
    val hololive: LiveData<ChannelsItem> = _hololive

    init {
        getHololiveData()
    }

    fun getHololiveData() {
        viewModelScope.launch {
            _status.value = HololiveApiStatus.LOADING
            try {
                _hololives.value = HoloApi.retrofitService.getData().channels
                _status.value = HololiveApiStatus.DONE
            } catch (e: Exception) {
                _status.value = HololiveApiStatus.ERROR
                _hololives.value = listOf()
                e.message?.let { Log.i("Pesan Error", it) }
            }
        }
    }

    fun onHololiveItemClicked(holo: ChannelsItem) {
        _hololive.value = holo
    }
}